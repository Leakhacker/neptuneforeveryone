package me.neptune.module.modules.misc;

import me.neptune.module.Module;

public class PacketMine extends Module {

    /**
     * todo
     */

    public PacketMine() {
        super("PacketMine", Category.Misc);
    }
}
