package me.neptune.mixin;

import net.minecraft.client.render.block.BlockModelRenderer;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(BlockModelRenderer.class)
public abstract class BlockModelRendererMixin {
}
