package me.neptune.mixin;

import org.spongepowered.asm.mixin.Mixin;
import net.minecraft.client.Mouse;

@Mixin(Mouse.class)
public class MouseMixin
{
}