package me.neptune.interfaces;

public interface ISimpleOption<T>
{
	public void forceSetValue(T newValue);
}
