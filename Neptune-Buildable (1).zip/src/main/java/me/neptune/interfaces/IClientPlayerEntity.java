package me.neptune.interfaces;

public interface IClientPlayerEntity {
	public void setNoclip(boolean state);
}
