package me.neptune.interfaces;

public interface IWorld {

}
