package me.neptune.interfaces;

public interface IChatInputSuggestor {
	public void show();
}
