package me.neptune.events.impl;

import me.neptune.events.Event;

public class UpdateWalkingEvent extends Event {
    public UpdateWalkingEvent(Stage stage) {
        super(stage);
    }
}
